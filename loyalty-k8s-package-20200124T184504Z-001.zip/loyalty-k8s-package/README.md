#  loyalty-k8s-package
Kubernetes Package for Loyalty Server
 
Read the Kubernetes packages [confluence page](https://confluence.wsgc.com/display/TAH/Kubernetes).
